package com.example.josimuddin.emess;

/**
 * Created by JosimUddin on 23/11/2017.
 */

public class ClassShowAllMembersMealList {
    public String meal;

}
