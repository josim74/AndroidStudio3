package com.example.josimuddin.emess;

/**
 * Created by JosimUddin on 24/11/2017.
 */

public class ClassBazarList {
    private String name;
    private String cost;

    public ClassBazarList() {
    }

    public ClassBazarList(String name, String cost) {
        this.name = name;
        this.cost = cost;
    }

    public String getName() {
        return name;
    }

    public String getCost() {
        return cost;
    }
}
