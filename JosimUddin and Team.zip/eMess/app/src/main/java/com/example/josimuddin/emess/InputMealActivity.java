package com.example.josimuddin.emess;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class InputMealActivity extends AppCompatActivity {

    private RecyclerView membersList;
    private DatabaseReference messDatabaseReference, userDatabaseReference;
    private FirebaseUser mCurrentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_meal);

        final String messKey = getIntent().getStringExtra("mess_id");

        membersList = findViewById(R.id.members_list);
        membersList.setHasFixedSize(true);
        membersList.setLayoutManager(new LinearLayoutManager(this));

        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        userDatabaseReference = FirebaseDatabase.getInstance().getReference().child("User");


        messDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Mess").child(messKey).child("members");


    }



    @Override
    protected void onStart() {
        super.onStart();


        FirebaseRecyclerAdapter<ClassInputMealList, MembersViewHolders>  firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<ClassInputMealList, MembersViewHolders>(
                ClassInputMealList.class, R.layout.members_single_layout, MembersViewHolders.class, messDatabaseReference
        ) {
            @Override
            protected void populateViewHolder(final MembersViewHolders viewHolder, ClassInputMealList model, int position) {
                String listUserId = getRef(position).getKey();

                userDatabaseReference.child(listUserId).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        String displayName = dataSnapshot.child("name").getValue().toString();
                        String phoneSelf = dataSnapshot.child("phone_self").getValue().toString();
                        String thumbImage = dataSnapshot.child("thumb_image").getValue().toString();

                        viewHolder.setDisplayName(displayName);
                        viewHolder.setPhoneSelf(phoneSelf);
                        viewHolder.setthumbImage(thumbImage, getApplicationContext());
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
                if (viewHolder.checkBox.isChecked()) {

                    viewHolder.btnPlus.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            double mValue = Double.parseDouble(viewHolder.tvMealNumbers.getText().toString());
                            mValue = mValue+0.5;
                            viewHolder.tvMealNumbers.setText(""+mValue);
                        }
                    });

                    viewHolder.btnMinus.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            double mValue = Double.parseDouble(viewHolder.tvMealNumbers.getText().toString());
                            if (mValue < 0.5) {
                                mValue = 0;
                                viewHolder.tvMealNumbers.setText(""+mValue);
                            }else {
                                mValue = mValue-0.5;
                                viewHolder.tvMealNumbers.setText(""+mValue);
                            }
                        }
                    });
                }else {
                    viewHolder.tvMealNumbers.setText("0");
                    viewHolder.btnMinus.setEnabled(false);
                    viewHolder.btnPlus.setEnabled(false);
                }
            }
        };
        membersList.setAdapter(firebaseRecyclerAdapter);

    }



    public static class MembersViewHolders extends RecyclerView.ViewHolder{
        View mView;
        Button btnPlus;
        Button btnMinus;
        TextView tvMealNumbers;
        CheckBox checkBox;
        public MembersViewHolders(View itemView) {
            super(itemView);
            mView = itemView;
            btnPlus = mView.findViewById(R.id.btn_plus_members);
            btnMinus = mView.findViewById(R.id.btn_minus_members);
            tvMealNumbers = mView.findViewById(R.id.tv_meal_numbers);
            checkBox = mView.findViewById(R.id.check_box_members);
        }
        public void setDisplayName(String name) {
            TextView displayName = mView.findViewById(R.id.tv_display_name_members);
            displayName.setText(name);
        }
        public void setPhoneSelf(String phone) {
            TextView phoneSelf = mView.findViewById(R.id.tv_phone_members);
            phoneSelf.setText(phone);
        }

        public void setthumbImage(String thumImage, Context context){
            CircleImageView thumbImageView = mView.findViewById(R.id.iv_thumbnails_members);
            Picasso.with(context).load(thumImage).placeholder(R.drawable.placeholder).into(thumbImageView);
        }



    }
}
