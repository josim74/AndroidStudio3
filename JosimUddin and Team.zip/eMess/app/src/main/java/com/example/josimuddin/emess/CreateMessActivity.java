package com.example.josimuddin.emess;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class CreateMessActivity extends AppCompatActivity {
    private EditText etMessName;
    private Button btnCreateMess;
private FirebaseAuth firebaseAuth;
private FirebaseUser firebaseUser;
private DatabaseReference messDatabaseReference;

    String current_uid;

    HashMap<String, String> userMap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_mess);
        etMessName = findViewById(R.id.et_mess_name);
        btnCreateMess = findViewById(R.id.btn_create_mess);



        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        current_uid = firebaseUser.getUid();
        messDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Mess");

        btnCreateMess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etMessName.getText().toString();
                if(name != null){
                    createMess(name);
                }else {
                    Toast.makeText(CreateMessActivity.this, "Please give a name for your mess", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }


    private void createMess(final String messName) {
/*
        FirebaseUser currentUser = firebaseAuth.getCurrentUser();
        final String uid = currentUser.getUid();
        firebaseDatabase = FirebaseDatabase.getInstance().getReference().child("Mess").child(uid);*/

        messDatabaseReference.child(current_uid).child("mess_name").setValue(messName).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                   
                    messDatabaseReference.child(current_uid).child("managers").child("primary").setValue(current_uid).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {

                                String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
                                messDatabaseReference.child(current_uid).child("members").child(current_uid).child("connection_date").setValue(date).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            DatabaseReference mUserDatabase = FirebaseDatabase.getInstance().getReference().child("User").child(current_uid).child("mess");
                                            mUserDatabase.setValue(current_uid).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    Toast.makeText(CreateMessActivity.this, "Mess Created Successfully", Toast.LENGTH_SHORT).show();
                                                    Intent mainIntent = new Intent(CreateMessActivity.this, MainActivity.class);
                                                    startActivity(mainIntent);

                                                }
                                            });
                                        }
                                    }
                                });
                            }
                        }
                    });
                }else {
                    Toast.makeText(CreateMessActivity.this, "Something is Wrong to create mess", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}
