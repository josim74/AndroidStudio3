package com.example.josimuddin.emess;

/**
 * Created by JosimUddin on 15/11/2017.
 */

public class ClassInputMealList {
    private String connection_date;

    public ClassInputMealList() {
    }

    public ClassInputMealList(String connection_date) {
        this.connection_date = connection_date;
    }

    public String getConnection_date() {
        return connection_date;
    }

    public void setConnection_date(String connection_date) {
        this.connection_date = connection_date;
    }
}
