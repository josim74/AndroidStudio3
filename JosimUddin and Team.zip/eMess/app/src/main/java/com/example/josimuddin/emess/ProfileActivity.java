package com.example.josimuddin.emess;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {

    //firebase...
    private DatabaseReference mUserDatabase;
    private  DatabaseReference mConnectionRequestDatabase;
    private  DatabaseReference messDatabaseReference;
    private FirebaseUser mCurrentUser;

    //views...
    private CircleImageView profileImage;
    private TextView tvDisplayName, tvEmail, tvPhoneSelf, tvPhoneHome, tvAddress, tvConnectedMess, tvConnectionRequest;
    private Button btnAccept;
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        //initailizing views...
        profileImage = findViewById(R.id.profile_image);
        tvDisplayName = findViewById(R.id.tv_display_name);
        tvEmail = findViewById(R.id.tv_email);
        tvPhoneSelf = findViewById(R.id.tv_phone_self);
        tvPhoneHome = findViewById(R.id.tv_phone_home);
        tvAddress = findViewById(R.id.tv_address);
        tvConnectedMess = findViewById(R.id.tv_connected_mess);
        btnAccept = findViewById(R.id.btn_accept_or_remove);
        tvConnectionRequest = findViewById(R.id.tv_connection_request);
        btnAccept = findViewById(R.id.btn_accept_or_remove);


        //initializing firebase...
        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        String current_uid = mCurrentUser.getUid();

        mConnectionRequestDatabase = FirebaseDatabase.getInstance().getReference().child("connection_request");
        messDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Mess");
        mUserDatabase = FirebaseDatabase.getInstance().getReference().child("User").child(current_uid);
        mUserDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String name = dataSnapshot.child("name").getValue().toString();
                String email = dataSnapshot.child("email").getValue().toString();
                String phoneSelf = dataSnapshot.child("phone_self").getValue().toString();
                String phoneHome = dataSnapshot.child("phone_home").getValue().toString();
                String address = dataSnapshot.child("address").getValue().toString();
                String image = dataSnapshot.child("profile_pic").getValue().toString();
                String connectedMessId = dataSnapshot.child("mess").getValue().toString();

                tvDisplayName.setText(name);
                tvEmail.setText(email);
                tvPhoneSelf.setText(phoneSelf);
                tvPhoneHome.setText(phoneHome);
                tvAddress.setText(address);
                if(!image.equals("default")){
                    Picasso.with(ProfileActivity.this).load(image).placeholder(R.drawable.placeholder).into(profileImage);
                }

                //Retrieve mess name................................

                if(!connectedMessId.equals("defaultValue")){

                    messDatabaseReference.child(connectedMessId).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            String messName = dataSnapshot.child("mess_name").getValue().toString();
                            tvConnectedMess.setText(messName);
                            btnAccept.setVisibility(View.GONE);
                            tvConnectionRequest.setVisibility(View.GONE);
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });

                }else {
                    tvConnectedMess.setText("No Connected Mess");
                }
                //--------------------------------------accept/Cancel/getREmove----------------------------------
                mConnectionRequestDatabase.child(mCurrentUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.hasChild("request_from")) {
                            final String request_from = dataSnapshot.child("request_from").getValue().toString();

                            if (request_from != null){
                                btnAccept.setText("Accept Connection Request");
                                btnAccept.setVisibility(View.VISIBLE);
                                tvConnectionRequest.setVisibility(View.VISIBLE);
                                btnAccept.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {

                                        String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

                                        messDatabaseReference.child(request_from).child("members").child(mCurrentUser.getUid()).child("connection_date").setValue(date).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    mConnectionRequestDatabase.child(mCurrentUser.getUid()).child("request_from").removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        @Override
                                                        public void onSuccess(Void aVoid) {
                                                            mUserDatabase.child("mess").setValue(request_from).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                @Override
                                                                public void onComplete(@NonNull Task<Void> task) {
                                                                    Toast.makeText(ProfileActivity.this, "You have Connected to mess successfully", Toast.LENGTH_SHORT).show();
                                                                }
                                                            });
                                                        }
                                                    });
                                                    Toast.makeText(ProfileActivity.this, "You have connected to mess Successfully", Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        });
                                    }
                                });
                            }
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });



    }
}
